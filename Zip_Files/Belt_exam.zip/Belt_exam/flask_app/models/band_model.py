from flask_app import DATABASE

from flask_app.config.mysqlconnection import connectToMySQL



class Band:
  def __init__( self, data):
    self.id = data['id']
    self.band = data['band']
    self.name = data['name']
    self.genre = data['genre']
    self.created_at = data['created_at']
    self.updated_at = data['updated_at']
    self.user_id = data['user_id']


  @classmethod
  def create (cls,data):
    query = "INSERT INTO bands ( band, name, genre, user_id ) VALUES ( %(band)s, %(name)s, %(genre)s, %(user_id)s);"
    return connectToMySQL(DATABASE).query_db(query,data)

  @classmethod
  def get_all( cls ):
    query = "SELECT * "
    query += "FROM bands;"
    
    result = connectToMySQL( DATABASE ).query_db( query )
    bands = []
    
    if len( result ) > 0:
      for band in result:
        bands.append( cls( band ) )
    return bands

  @classmethod
  def get_one(cls, data):
    query = "SELECT * "
    query += "FROM bands "
    query += "WHERE id = %(id)s;"
    
    result = connectToMySQL( DATABASE ).query_db( query, data )
    
    if len( result ) > 0:
      return cls( result[0] )
    else: 
      return None


  @classmethod
  def delete_one( cls, data ):
    query = "DELETE FROM bands "
    query += "WHERE id = %(id)s;"
    
    return connectToMySQL( DATABASE ).query_db( query, data )

  @classmethod
  def update_one( cls, data):
    query = "UPDATE bands "
    query += "SET name = %(name)s, band = %(band)s, genre = %(genre)s, "
    query += "user_id = %(user_id)s, created_at = %(created_at)s;"
    
    return connectToMySQL( DATABASE ).query_db( query, data )