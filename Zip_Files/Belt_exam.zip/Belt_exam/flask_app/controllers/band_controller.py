import re
from flask import session, request, render_template, redirect, flash
from flask_app import app
from flask_app.models.band_model import Band
from flask_app.models.user_model import User

@app.route( "/display/band" )
def display_band():
  if User.validate_session():
    return render_template( "show_mybands.html" )
  else:
    return redirect ("/")

@app.route( "/band/new" )
def display_create_todo():
  if User.validate_session() == False:
    return redirect( "/login" )
  else:
    return render_template( "new_band.html" )


@app.route( "/band/new", methods = [ 'POST'] )
def create_band():
  data = {
    "band" : request.form[ 'band' ],
    "name" : request.form[ 'name' ],
    "genre" : request.form['genre'],
    "user_id" : session[ 'user_id' ]
  }
  Band.create( data )
  
  return redirect( "/dashboard" )

@app.route ( "/dashboard" )
def get_bands():
  if User.validate_session():
    bands = Band.get_all()
    return render_template( "dashboard.html", bands = bands )
  else:
    return redirect("/")

@app.route( "/band/<int:id>")
def band_get_one( id ):
  data = {
    "id" : id
  }
  
  band = Band.get_one( data )
  return render_template("show_mybands.html", band = band )

@app.route( "/band/delete/<int:id>" )
def delete_band( id ):
  data = {
    "id" : id 
  }
  Band.delete_one( data )
  return redirect( "/dashboard" )

@app.route( "/band/edit/<int:id>")
def display_band_edit( id ):
  if User.validate_session():
    data = {
      "id" : id
    }
    band = Band.get_one( data )
    return render_template( "edit_band.html", band = band )
  else:
    return redirect("/")

@app.route( "/band/edit/<int:id>", methods = [' POST '] )
def update_band( id ):
  data = {
    "id" : id,
    "bands" : request.form [ 'bands'],
    "name" : request.form [ 'name' ],
    "genre" : request.form[ 'genre' ],
    "user_id" : session[ 'user_id' ],
    "created_at" : request.form [ 'created_at']
  }
  Band.update_one( data )
  return redirect( "/dashboard" )
