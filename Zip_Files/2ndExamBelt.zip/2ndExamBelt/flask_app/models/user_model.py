from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash, session
from flask_app.models.painting_model import Painting
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')



class User:
  def __init__( self, data):
    self.id = data[ 'id' ]
    self.first_name = data[ 'first_name' ]
    self.last_name = data[ 'last_name' ]
    self.email = data[ 'email' ]
    self.password = data[ 'password' ]
    self.created_at = data[ 'created_at' ]
    self.updated_at = data[ 'updated_at' ]

  @classmethod
  def get_one( cls, data ):
    query = "SELECT * "
    query += "FROM users "
    query += "WHERE email = %(email)s;"
    result = connectToMySQL( DATABASE ).query_db( query, data )
    if len( result ) > 0:
      return cls( result[0])
    else:
      return None

  @classmethod
  def get_one_with_paintings(cls, data):
    query = "SELECT * FROM users JOIN paintings ON users.id = paintings.user_id WHERE users.id = %(id)s;"
    result = connectToMySQL(DATABASE).query_db(query,data)
    if len( result ) > 0 :
      current_user = cls( result[0] )
      list_paintings = []
      for row in result:
        current_painting = {
            "id" : row[ "paintings.id" ],
            "description" : row[ "description" ],
            "price" : row[ "price" ],
            "created_at" : row[ "painting.created_at" ],
            "updated_at" : row[ "painting.updated_at" ],
            "user_id" : row[ "user_id" ]
        } 
        description = Painting( current_description )
        list_painting.append( description )
      current_user.list_todos = list_bands
      return current_user
    return None


  @classmethod
  def create ( cls, data ):
    query = "INSERT INTO users( email, first_name, last_name, password )"
    query += "VALUES( %(email)s, %(first_name)s, %(last_name)s, %(password)s );"
    return  connectToMySQL( DATABASE ).query_db( query, data )


#### VALIDATIONS ##########
  @staticmethod
  def validate_register( data ):
    isValid = True
    
    if data['first_name'] == "error_register_first_name":
      isValid = False
      flash("Please provide your first name.", "error_register_first_name" )
    
    
    #### Flashes when there is less than 2 characters #########
    if len(data['first_name'] ) < 2:
      isValid = False
      flash( "Your Name must have at least 2 characters.", "error_register_first_name")
    
    
    if data['last_name'] == "error_register_last_name":
      isValid = False
      flash("Please provide a first name.", )
    #### Flashes when there is less than 2 characters #########
    
    
    if len(data['last_name'] ) < 2:
      isValid = False
      flash( "Your Name must have at least 2 characters.", "error_register_last_name")
    
    
    if data['email'] == "":
      isValid = False
      flash("Please provide a email.", "error_register_email" )

    if data['password'] != data['password_confirmation']:
      isValid = False
      flash("Your password do not match.", "error_register_password_confirmation" )

    if len( data[ 'password' ] ) < 8:
      flash( "Password must be at least 8 characters long.", "error_register_password" )
    
    
    if data['password_confirmation'] == "":
      isValid = False
      flash("You must provide a password confirmation.", "error_register_password" )
    
    if not EMAIL_REGEX.match( data[ 'email' ] ):
      flash( "Please provide a valid email.", "error_register_email" )
      isValid = False
    
    return isValid

  @staticmethod
  def validate_login( data ):
    isValid = True
    if data[ 'email' ] == "":
      flash( "Please provide your email.", "error_email" )
      isValid = False
    if data[ 'password' ] == "":
      flash( "Please provide your password.", "error_password" )
      isValid = False
    return isValid

  
  @staticmethod
  def validate_session():
    if "user_id" not in session:
      return False
    else:
      return True