from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash,session


class Painting:
  def __init__(self, data):
    self.id = data['id']
    self.title = data['title']
    self.description = data['description']
    self.price = data['price']
    self.created_at =  data['created_at']
    self.updated_at =  data['updated_at']
    self.user_id =  data['user_id']

  @classmethod
  def create(cls,data):
    query ="INSERT INTO paintings ( title, description, price, user_id) " 
    query += "VALUES( %(title)s, %(description)s, %(price)s, %(user_id)s);"
    return connectToMySQL(DATABASE).query_db(query,data)

  @classmethod
  def get_all( cls ):
    query = "SELECT * "
    query += "FROM paintings;"
    
    result = connectToMySQL( DATABASE ).query_db( query )
    paintings = []
    
    if len( result ) > 0:
      for painting in result:
        paintings.append( cls( painting ) )
    return paintings

  @classmethod
  def get_one(cls, data):
    query = "SELECT * "
    query += "FROM paintings "
    query += "WHERE id = %(id)s;"
    
    result = connectToMySQL( DATABASE ).query_db( query, data )
    
    if len( result ) > 0:
      return cls( result[0] )
    else: 
      return None

  @classmethod
  def delete_one( cls, data ):
    query = "DELETE FROM paintings "
    query += "WHERE id = %(id)s;"
    return connectToMySQL( DATABASE ).query_db( query, data )

  @classmethod
  def update_one( cls, data):
    query = "UPDATE paintings "
    query += "SET title = %(title)s, description = %(description)s, price = %(price)s "
    query += "WHERE id = %(id)s;"
    return connectToMySQL( DATABASE ).query_db( query, data )

  @staticmethod
  def validate_painting(data):
    isValid = True
    if len(data['title']) < 2:
      flash("Please provide a painting title with more than 2 characters", 'error_title')
      isValid = False
    if len(data['description']) < 10:
      flash("Please provide a description of more than 10 or characters", 'error_description')
      isValid = False
    if len(data['price']) < 1:
      flash("Please provide greater than 0 dollars ", 'error_price')
      isValid = False
    return isValid