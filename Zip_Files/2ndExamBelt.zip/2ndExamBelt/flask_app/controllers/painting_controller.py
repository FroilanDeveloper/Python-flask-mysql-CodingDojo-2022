import re
from flask import session, request, render_template, redirect, flash
from flask_app import app
from flask_app.models.painting_model import Painting
from flask_app.models.user_model import User
from flask_bcrypt import Bcrypt

@app.route( "/display/painting" )
def display_painting():
  if User.validate_session():
    return render_template( "displayPainting.html", paintings = Painting.get_all() )
  else:
    return redirect ("/")

@app.route( "/painting/new" )
def display_create_painting():
  if User.validate_session() == False:
    return redirect( "/login" )
  else:
    return render_template( "new_painting.html" )


@app.route( "/painting/new", methods = [ 'POST'] )
def create_painting():
  if not Painting.validate_painting(request.form):
    # 
    return redirect(f"/painting/new")
  else:
    data = {
    "title" : request.form[ 'title' ],
    "description" : request.form[ 'description' ],
    "price" : request.form['price'],
    "user_id" : session[ 'user_id' ]
    }
    Painting.create( data )
  
    return redirect( "/paintings" )

@app.route ( "/paintings" )
def get_paintings():
  if User.validate_session():
    paintings = Painting.get_all()
    return render_template( "paintings.html", paintings = paintings )
  else:
    return redirect("/")

@app.route( "/painting/<int:id>")
def painting_get_one( id ):
  data = {
    "id" : id
  }
  
  painting = Painting.get_one( data )
  return render_template("displayPainting.html", painting = painting )

@app.route( "/painting/delete/<int:id>" )
def delete_painting( id ):
  data = {
    "id" : id 
  }
  Painting.delete_one( data )
  return redirect( "/paintings" )

@app.route( "/painting/edit/<int:id>")
def display_painting_edit( id ):
  if User.validate_session():
    data = {
      "id" : id
    }
    painting = Painting.get_one( data )
    return render_template( "edit_painting.html", painting = painting )
  else:
    return redirect("/")

@app.route( "/edit/<int:id>", methods = ['POST'] )
def update_painting( id ):
  if not Painting.validate_painting(request.form):
    # 
    return redirect(f"/painting/edit/{id}")
  else:
    data = {
      "id" : id,
      "title" : request.form[ 'title' ],
      "description" : request.form[ 'description' ],
      "price" : request.form[ 'price' ]
      # "user_id" :
    }
    Painting.update_one( data )
    return redirect( "/paintings" )
