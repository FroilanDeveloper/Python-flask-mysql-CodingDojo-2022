from flask import Flask

DATABASE = "dojos_ninjas_schema"

app = Flask(__name__)