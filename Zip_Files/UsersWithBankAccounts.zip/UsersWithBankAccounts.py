class BankAccount:
  
  all_accounts = []
  
  def __init__( self, int_rate, balance, ):
    self.int_rate = int_rate
    self.balance = balance

    BankAccount.all_accounts.append(self)
    
  def deposit( self, amount ):
    self.balance += amount
    return self
  
  
  def withdraw(self, amount):
    if (self.balance < amount):
      self.balance -= 5
      print("\n Insufficient funds: Charging a $5 fee ")
      return self
    else:
      self.balance -= amount
      return self
  
  def display_account_info(self):
    print( f"Balance: ${self.balance}" )
    return self

  def yield_interest(self):
    calculated_rate = self.balance * self.int_rate
    self.balance = self.balance + calculated_rate
    return self

  @classmethod
  def Accounts(cls):
    for account in cls.all_accounts:
      print(account.first_name+ "'s balance is: ", account.balance)

BankAccount.Accounts()


class User:
  
  all_users = []
  
  def __init__(self, first_name):
    self.first_name = first_name
    self.account = BankAccount( 0.02, 0)
    User.all_users.append(self)
    

  def display_user_balance(self):
    print(f"User: {self.first_name}'s balance is ${self.account.balance}" )
    return self

  @classmethod
  def all_user_balance(cls):
    for each_user in cls.all_users:
      print(f"Balance is ${each_user.account.balance}" )


zoro = User("Zoro")
chopper = User("Chopper")

zoro.account.deposit(9000532).withdraw(293414)
zoro.display_user_balance()

chopper.account.deposit(100)
chopper.display_user_balance()

print('------')

User.all_user_balance()