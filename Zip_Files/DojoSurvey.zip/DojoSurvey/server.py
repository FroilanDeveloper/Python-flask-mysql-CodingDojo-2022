import secrets
from flask import Flask, render_template, request, redirect, session

app = Flask ( __name__ )
app.secret_key = "I'm finally done"

@app.route("/")
def index():
  return render_template("index.html")


@app.route("/process", methods=["POST"])
def display_process():
  session["new_info"] = {
    "name": request.form["name"],
    "locations": request.form["locations"],
    "language": request.form["language"],
    "commentoverhere": request.form["commentoverhere"]
  }
  return redirect("/result")


@app.route("/result")
def display_result():
  return render_template("result.html")


if __name__ == "__main__":
  app.run(debug = True)